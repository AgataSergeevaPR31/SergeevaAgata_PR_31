﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SergeevaA_PR_31_zd_1
{
    class Program
    {
        static void Main(string[] args)
        {

            string inputFile = "input.txt"; 
            string outputFile = "output.txt";

            string[] parts = File.ReadAllText(inputFile).Split(' ');
            Console.WriteLine($"Кол-во рыбаков: {parts[0]}\nКол-во рыбы:{parts[1]}");
            int k = int.Parse(parts[0]);
            int n = int.Parse(parts[1]);

            double value = n / k;
            int outputFish = (int)Math.Floor(value);

            File.WriteAllText(outputFile, outputFish.ToString());

            Console.WriteLine(outputFish);

            Console.ReadKey();
        }
    }
}
