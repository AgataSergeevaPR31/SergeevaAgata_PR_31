﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SergeevaA_PR_31_zd_4
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputFile = "input.txt";
            string outputFile = "output.txt";

            string[] input = File.ReadAllLines(inputFile);

            string[] length = input[0].Split(' ');
            int messageLength = int.Parse(length[0]);
            int magazineLength = int.Parse(length[1]);

            Console.WriteLine($"{messageLength} {magazineLength}");

            string message = input[1];
            string magazine = input[2];

            Console.WriteLine($"{message}\n{magazine}");

            bool note = true;
            string noWord = "";
            foreach (char word in message)
            {
                if (magazine.Contains(word.ToString()))
                {
                    magazine = magazine.Remove(magazine.IndexOf(word), 1);
                }
                else
                {
                    
                    note = false;
                    Console.WriteLine($"Отсутсвует: {word}\n");
                    noWord += $"{word}";
                    break;
                }
            }

            if (note) File.WriteAllText("output.txt", "GOOD NOTE");
            else File.WriteAllText("output.txt", noWord);

        }
    }
}

