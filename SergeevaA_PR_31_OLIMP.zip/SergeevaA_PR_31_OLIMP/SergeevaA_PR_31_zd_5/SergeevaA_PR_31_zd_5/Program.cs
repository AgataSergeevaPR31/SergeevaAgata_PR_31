﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SergeevaA_PR_31_zd_5
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputFile = "input.txt";
            string outputFile = "output.txt";

            string[] parts = File.ReadAllLines(inputFile);
            int N = int.Parse(parts[0]); 
            string[] driver = parts[1].Split(' ');
            int V = int.Parse(driver[0]);
            int t = int.Parse(driver[1]);

            Console.WriteLine($"Кол-во кругов: {N}\nСкорость автомобиля:{V}\nВремя: {t}\n");

            int K = 0;
            int s = V * t;
            if (s < N) K = s;
            else if (s == N) K = 0;
            else
            {
                K = -(N - s);
            }

            Console.WriteLine(K);
            File.WriteAllText(outputFile, K.ToString());
        }
    }
}