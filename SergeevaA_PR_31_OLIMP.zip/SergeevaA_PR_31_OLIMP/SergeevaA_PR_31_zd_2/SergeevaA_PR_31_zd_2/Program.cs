﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SergeevaA_PR_31_zd_2
{
    class Program
    {
        static void Main(string[] args)
        {

            string inputFile = "input.txt";
            string outputFile = "output.txt";

            string[] parts = File.ReadAllLines(inputFile);
            Console.WriteLine($"Кол-во слов: {parts[0]}\n");

            int n = int.Parse(parts[0]);

            using (StreamWriter writer = new StreamWriter(outputFile))
            {
                for (int i = 1; i <= n; i++)
                {
                    Console.WriteLine(parts[i]);
                    string word = parts[i];
                    string wordUp = word.ToUpper();
                    string newWord = Perevorot(wordUp);
                    if (newWord == wordUp)
                    {
                        writer.WriteLine("YES");
                        Console.WriteLine("YES\n");
                    }
                    else
                    {
                        writer.WriteLine("NO");
                        Console.WriteLine("NO\n");
                    }
                }
            }

            Console.ReadKey();
        }


        static string Perevorot(string wordUp)
        {
            char[] charWord = wordUp.ToCharArray();
            Array.Reverse(charWord);
            string newWord = "";
            for (int i = 0; i < charWord.Length; i++)
            {
                newWord += charWord[i];
            }

            return newWord;
        }
    }
}
